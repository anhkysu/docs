﻿namespace BioMetrixCore
{
    public enum ClearFlag
    {
        UserData = 5,
        FingerPrintTemplate = 2
    }
}
