﻿namespace BioMetrixCore
{
    internal class DeviceTimeInfo
    {
        public string DeviceTime { get; set; }
    }
}
