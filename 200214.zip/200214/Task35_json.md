## 35.1.Android yêu cầu chức năng tạo sản phẩm mới
***Khi người dùng muốn lưu sản phẩm vừa tạo thì android gửi dữ liệu sản phẩm vừa tạo đó xuống Firmware***
Lưu ý: productId là mã GUID dùng thư viện tự sinh và ko thể chỉnh sửa dc, thông số Id là cái count số sản phẩm trên app, cũng ko thay đổi được
>Android request
```json
{
  "topic":"settingCreateProducts",
  "type":"request",
  "content":{
    "productPrices":int,
    "productId":string
  }  
}
```
***Firmware phản hồi lên app tạo sản phẩm từ app -> firmware thành công***
>Firmware reponds
```json
{
  "topic":"settingCreateProducts",
  "type":"response",
  "content":{"status":"ok"}
}
```
---
## 35.2.Android yêu cầu xóa sản phẩm hiện có
***Khi người dùng muốn xóa sản phẩm thì anadroid gửi xuống firmware để xóa***
>Android request
```json
{
  "topic":"settingDeleteProducts",
  "type":"request",
  "content":{
    "productId":string,
  }  
}
```
---
***Firmware phản hồi lên app xóa sản phẩm thành công***
>Firmware reponds
```json
{
  "topic":"settingDeleteProducts",
  "type":"response",
  "content":{"status":"ok"}
}
```
## 35.3.Android cập nhật dữ liệu sản phẩm xuống firmware
***Khi người dùng muốn xóa sản phẩm thì anadroid gửi xuống firmware để xóa***
>Android request
```json
{
  "topic":"settingUpdateProducts",
  "type":"request",
  "content":{
    "productPrices":int,
    "productId":string
  }
}
```
***Firmware phản hồi lên app xóa sản phẩm thành công***
>Firmware reponds
```json
{
  "topic":"settingUpdateProducts",
  "type":"response",
  "content":{"status":"ok"}
}
```